console.log(a);
var a = 'BC Ko';