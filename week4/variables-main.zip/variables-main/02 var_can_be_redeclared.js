var x = "BC Ko";

var x = 0;

console.log(x);