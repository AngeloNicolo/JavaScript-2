console.log(a);
let a = 'BC Ko';