let x = 'Genie';
console.log(x);

x = 'BC Ko';
console.log(x);