{
    var x = 'BC Ko';
}
console.log(x);
