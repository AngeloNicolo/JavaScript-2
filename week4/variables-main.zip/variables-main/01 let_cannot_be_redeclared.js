let x = "BC Ko";

let x = 0;

console.log(x);