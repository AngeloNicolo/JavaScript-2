{
    let x = 'BC Ko';
}
console.log(x);
