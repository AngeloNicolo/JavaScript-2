const x = {
    genie: "dog" 
};

console.log(x);

x = {
    BC: "human"
};

console.log(x);